</div>
</div>

<footer class="bg-dark text-white text-center py-3">
    <P class="mb-0">&copy; <?= date('Y') ?> Sistem Perpustakaan.</P>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../js/script.js"></script>
<script src="js/script.js"></script>
</body>

</html>